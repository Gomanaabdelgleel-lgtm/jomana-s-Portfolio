from patient import Patient
from hospital_system import HospitalSystem
from diagnosis import Diagnosis
from treatment import Treatment
from vital_signs import VitalSigns
from injury import Injury


hospital = HospitalSystem()


while True:

    print("\n========== Hospital Management System ==========")
    print("1. Add Patient")
    print("2. View Patients")
    print("3. Search Patient")
    print("4. Update Patient")
    print("5. Delete Patient")
    print("6. Add Diagnosis")
    print("7. Add Treatment")
    print("8. Add Vital Signs")
    print("9. First Aid")
    print("10. Display Full Record")
    print("11. Total Patients")
    print("0. Exit")

    choice = input("\nEnter your choice: ")

    # ------------------------------------------------ #

    if choice == "1":

        patient = Patient(

            int(input("Patient ID: ")),

            input("Medical Record Number: "),

            input("Patient Name: "),

            int(input("Age: ")),

            input("Gender: "),

            input("Phone Number: "),

            input("Blood Type: "),

            input("Address: ")

        )

        hospital.add_patient(patient)

    # ------------------------------------------------ #

    elif choice == "2":

        print(hospital.view_patients())

    # ------------------------------------------------ #

    elif choice == "3":

        patient = hospital.search_patient(

            int(input("Enter Patient ID: "))

        )

        if patient:

            print(patient.display_patient())

        else:

            print("Patient Not Found.")

    # ------------------------------------------------ #

    elif choice == "4":

        patient_id = int(input("Patient ID: "))

        hospital.update_patient(

            patient_id,

            input("Medical Record: "),

            input("Name: "),

            int(input("Age: ")),

            input("Gender: "),

            input("Phone: "),

            input("Blood Type: "),

            input("Address: ")

        )

    # ------------------------------------------------ #

    elif choice == "5":

        hospital.remove_patient(

            int(input("Patient ID: "))

        )

    # ------------------------------------------------ #

    elif choice == "6":

        patient = hospital.search_patient(

            int(input("Patient ID: "))

        )

        if patient:

            diagnosis = Diagnosis(

                input("Diagnosis ID: "),

                input("Doctor Name: "),

                input("Date: ")

            )

            diagnosis.add_diagnosis(

                float(input("Temperature: ")),

                input("Headache (y/n): ").lower() == "y",

                int(input("Headache Degree: ")),

                input("Stomach Pain (y/n): ").lower() == "y",

                int(input("Stomach Pain Degree: ")),

                input("Cough (y/n): ").lower() == "y",

                input("Throat Pain (y/n): ").lower() == "y",

                input("Burn (y/n): ").lower() == "y",

                int(input("Burn Degree: "))

            )

            diagnosis.notes = input("Notes: ")

            patient.diagnosis = diagnosis

            print("Diagnosis Added.")

        else:

            print("Patient Not Found.")

    # ------------------------------------------------ #

    elif choice == "7":

        patient = hospital.search_patient(

            int(input("Patient ID: "))

        )

        if patient:

            treatment = Treatment()

            treatment.add_treatment(

                input("Medicine Name: "),

                input("Dosage: "),

                input("Duration: "),

                input("Instructions: ")

            )

            patient.treatment = treatment

            print("Treatment Added.")

        else:

            print("Patient Not Found.")

    # ------------------------------------------------ #

    elif choice == "8":

        patient = hospital.search_patient(

            int(input("Patient ID: "))

        )

        if patient:

            vital = VitalSigns(

                patient,

                input("Test Type: ")

            )

            print(

                vital.book_appointment(

                    input("Booking Date (YYYY-MM-DD): ")

                )

            )

            print(

                vital.enter_result(

                    float(input("Result: "))

                )

            )

            patient.vital_signs = vital

        else:

            print("Patient Not Found.")

    # ------------------------------------------------ #

    elif choice == "9":

        injury = Injury()

        print()

        print("1-Cut")
        print("2-Epilepsy")
        print("3-Fracture")
        print("4-CPR")
        print("5-Choking")
        print("6-Burn")

        choice_num = int(input("\nChoose: "))

        chemical = False

        if choice_num == 6:

            chemical = input(

                "Chemical Burn? (y/n): "

            ).lower() == "y"

        print()

        print(

            injury.get_first_aid(

                choice_num,

                chemical

            )

        )

    # ------------------------------------------------ #

    elif choice == "10":

        print(

            hospital.display_record(

                int(input("Patient ID: "))

            )

        )

    # ------------------------------------------------ #

    elif choice == "11":

        print(

            "Total Patients:",

            hospital.total_patients()

        )

    # ------------------------------------------------ #

    elif choice == "0":

        print("Thank You ❤️")

        break

    else:

        print("Invalid Choice.")


