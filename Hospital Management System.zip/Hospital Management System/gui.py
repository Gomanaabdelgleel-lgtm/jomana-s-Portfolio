import tkinter as tk
from tkinter import messagebox

from patient import Patient
from hospital_system import HospitalSystem
from diagnosis import Diagnosis
from treatment import Treatment
from vital_signs import VitalSigns
from injury import Injury


# ==========================================================
#                 CREATE HOSPITAL OBJECT
# ==========================================================

hospital = HospitalSystem()


# ==========================================================
#                    MAIN WINDOW
# ==========================================================

root = tk.Tk()

root.title("Hospital Management System")

root.geometry("900x650")

root.resizable(False, False)

root.configure(bg="#EAF4FF")


# ==========================================================
#                      TITLE
# ==========================================================

title = tk.Label(

    root,

    text="🏥 Hospital Management System",

    font=("Arial", 22, "bold"),

    fg="#0B5394",

    bg="#EAF4FF"

)

title.pack(pady=20)


# ==========================================================
#                  SHOW MESSAGE
# ==========================================================

def show(text):

    messagebox.showinfo(

        "Hospital System",

        text

    )


# ==========================================================
#                 ADD PATIENT WINDOW
# ==========================================================

def add_patient_window():

    win = tk.Toplevel(root)

    win.title("Add Patient")

    win.geometry("420x420")

    win.configure(bg="#EAF4FF")

    labels = [

        "Patient ID",

        "Medical Record",

        "Name",

        "Age",

        "Gender",

        "Phone",

        "Blood Type",

        "Address"

    ]

    entries = []

    for i, text in enumerate(labels):

        tk.Label(

            win,

            text=text,

            bg="#EAF4FF",

            fg="#0B5394",

            font=("Arial",10,"bold")

        ).grid(

            row=i,

            column=0,

            padx=10,

            pady=8,

            sticky="w"

        )

        entry = tk.Entry(

            win,

            width=28

        )

        entry.grid(

            row=i,

            column=1,

            padx=5,

            pady=8

        )

        entries.append(entry)

    def save():

        try:

            patient = Patient(

                int(entries[0].get()),

                entries[1].get(),

                entries[2].get(),

                int(entries[3].get()),

                entries[4].get(),

                entries[5].get(),

                entries[6].get(),

                entries[7].get()

            )

            hospital.add_patient(patient)

            messagebox.showinfo(

                "Success",

                "Patient Added Successfully."

            )

            win.destroy()

        except Exception as e:

            messagebox.showerror(

                "Error",

                str(e)

            )

    tk.Button(

        win,

        text="Save",

        width=18,

        bg="#1976D2",

        fg="white",

        activebackground="#1565C0",

        activeforeground="white",

        font=("Arial",10,"bold"),

        command=save

    ).grid(

        row=8,

        column=0,

        columnspan=2,

        pady=20

    )


# ==========================================================
#                 VIEW PATIENTS
# ==========================================================

def view_patients():

    show(

        hospital.view_patients()

    )


# ==========================================================
#                 SEARCH PATIENT
# ==========================================================

def search_patient():

    win = tk.Toplevel(root)

    win.title("Search Patient")

    win.geometry("320x150")

    win.configure(bg="#EAF4FF")

    tk.Label(

        win,

        text="Patient ID",

        bg="#EAF4FF",

        fg="#0B5394",

        font=("Arial",10,"bold")

    ).pack(pady=10)

    patient_id = tk.Entry(win, width=25)

    patient_id.pack()

    def search():

        try:

            patient = hospital.search_patient(

                int(patient_id.get())

            )

            if patient:

                show(patient.display_patient())

                win.destroy()

            else:

                messagebox.showerror(

                    "Error",

                    "Patient Not Found."

                )

        except:

            messagebox.showerror(

                "Error",

                "Invalid Patient ID."

            )

    tk.Button(

        win,

        text="Search",

        width=15,

        bg="#2196F3",

        fg="white",

        activebackground="#1976D2",

        activeforeground="white",

        font=("Arial",10,"bold"),

        command=search

    ).pack(pady=15)


# ==========================================================
#                 UPDATE PATIENT
# ==========================================================

def update_patient():

    win = tk.Toplevel(root)

    win.title("Update Patient")

    win.geometry("420x420")

    win.configure(bg="#EAF4FF")

    labels = [

        "Patient ID",

        "Medical Record",

        "Name",

        "Age",

        "Gender",

        "Phone",

        "Blood Type",

        "Address"

    ]

    entries = []

    for i, text in enumerate(labels):

        tk.Label(

            win,

            text=text,

            bg="#EAF4FF",

            fg="#0B5394",

            font=("Arial",10,"bold")

        ).grid(

            row=i,

            column=0,

            padx=10,

            pady=8,

            sticky="w"

        )

        entry = tk.Entry(win, width=28)

        entry.grid(

            row=i,

            column=1,

            padx=5,

            pady=8

        )

        entries.append(entry)

    def update():

        try:

            success = hospital.update_patient(

                int(entries[0].get()),

                entries[1].get(),

                entries[2].get(),

                int(entries[3].get()),

                entries[4].get(),

                entries[5].get(),

                entries[6].get(),

                entries[7].get()

            )

            if success:

                messagebox.showinfo(

                    "Success",

                    "Patient Updated Successfully."

                )

                win.destroy()

            else:

                messagebox.showerror(

                    "Error",

                    "Patient Not Found."

                )

        except:

            messagebox.showerror(

                "Error",

                "Invalid Data."

            )

    tk.Button(

        win,

        text="Update",

        width=15,

        bg="#42A5F5",

        fg="white",

        activebackground="#1E88E5",

        activeforeground="white",

        font=("Arial",10,"bold"),

        command=update

    ).grid(

        row=8,

        column=0,

        columnspan=2,

        pady=20

    )


# ==========================================================
#                 DELETE PATIENT
# ==========================================================

def delete_patient():

    win = tk.Toplevel(root)

    win.title("Delete Patient")

    win.geometry("320x150")

    win.configure(bg="#EAF4FF")

    tk.Label(

        win,

        text="Patient ID",

        bg="#EAF4FF",

        fg="#0B5394",

        font=("Arial",10,"bold")

    ).pack(pady=10)

    patient_id = tk.Entry(win, width=25)

    patient_id.pack()

    def delete():

        try:

            success = hospital.remove_patient(

                int(patient_id.get())

            )

            if success:

                messagebox.showinfo(

                    "Success",

                    "Patient Deleted Successfully."

                )

                win.destroy()

            else:

                messagebox.showerror(

                    "Error",

                    "Patient Not Found."

                )

        except:

            messagebox.showerror(

                "Error",

                "Invalid Patient ID."

            )

    tk.Button(

        win,

        text="Delete",

        width=15,

        bg="#1565C0",

        fg="white",

        activebackground="#0D47A1",

        activeforeground="white",

        font=("Arial",10,"bold"),

        command=delete

    ).pack(pady=15)

# ==========================================================
#                 ADD DIAGNOSIS
# ==========================================================

def add_diagnosis():

    win = tk.Toplevel(root)
    win.title("Add Diagnosis")
    win.geometry("450x600")
    win.configure(bg="#EAF4FF")

    labels = [

        "Patient ID",
        "Diagnosis ID",
        "Doctor Name",
        "Date",
        "Temperature",
        "Headache (y/n)",
        "Headache Degree",
        "Stomach Pain (y/n)",
        "Stomach Degree",
        "Cough (y/n)",
        "Throat Pain (y/n)",
        "Burn (y/n)",
        "Burn Degree",
        "Notes"

    ]

    entries = []

    for i, label in enumerate(labels):

        tk.Label(

            win,

            text=label,

            bg="#EAF4FF",

            fg="#0B5394",

            font=("Arial",10,"bold")

        ).grid(row=i,column=0,padx=10,pady=5,sticky="w")

        e = tk.Entry(win,width=28)

        e.grid(row=i,column=1,padx=5,pady=5)

        entries.append(e)

    def save():

        patient = hospital.search_patient(int(entries[0].get()))

        if patient is None:

            messagebox.showerror("Error","Patient Not Found")

            return

        diagnosis = Diagnosis(

            entries[1].get(),

            entries[2].get(),

            entries[3].get()

        )

        diagnosis.add_diagnosis(

            float(entries[4].get()),

            entries[5].get().lower()=="y",

            int(entries[6].get()),

            entries[7].get().lower()=="y",

            int(entries[8].get()),

            entries[9].get().lower()=="y",

            entries[10].get().lower()=="y",

            entries[11].get().lower()=="y",

            int(entries[12].get())

        )

        diagnosis.notes = entries[13].get()

        patient.diagnosis = diagnosis

        messagebox.showinfo("Success","Diagnosis Added Successfully")

        win.destroy()

    tk.Button(

        win,

        text="Save",

        width=18,

        bg="#1976D2",

        fg="white",

        font=("Arial",10,"bold"),

        command=save

    ).grid(row=14,column=0,columnspan=2,pady=20)


# ==========================================================
#                 ADD TREATMENT
# ==========================================================

def add_treatment():

    win = tk.Toplevel(root)

    win.title("Add Treatment")

    win.geometry("400x300")

    win.configure(bg="#EAF4FF")

    tk.Label(

        win,

        text="Patient ID",

        bg="#EAF4FF",

        fg="#0B5394",

        font=("Arial",10,"bold")

    ).grid(row=0,column=0,padx=10,pady=10)

    patient_id = tk.Entry(win,width=28)

    patient_id.grid(row=0,column=1)

    labels=[

        "Medicine",

        "Dosage",

        "Duration",

        "Instructions"

    ]

    entries=[]

    for i,text in enumerate(labels):

        tk.Label(

            win,

            text=text,

            bg="#EAF4FF",

            fg="#0B5394",

            font=("Arial",10,"bold")

        ).grid(row=i+1,column=0,padx=10,pady=8)

        e=tk.Entry(win,width=28)

        e.grid(row=i+1,column=1)

        entries.append(e)

    def save():

        patient=hospital.search_patient(int(patient_id.get()))

        if patient is None:

            messagebox.showerror("Error","Patient Not Found")

            return

        treatment=Treatment()

        treatment.add_treatment(

            entries[0].get(),

            entries[1].get(),

            entries[2].get(),

            entries[3].get()

        )

        patient.treatment=treatment

        messagebox.showinfo("Success","Treatment Added Successfully")

        win.destroy()

    tk.Button(

        win,

        text="Save",

        width=18,

        bg="#1976D2",

        fg="white",

        font=("Arial",10,"bold"),

        command=save

    ).grid(row=5,column=0,columnspan=2,pady=20)


# ==========================================================
#                 ADD VITAL SIGNS
# ==========================================================

def add_vital_signs():

    win=tk.Toplevel(root)

    win.title("Vital Signs")

    win.geometry("420x260")

    win.configure(bg="#EAF4FF")

    labels=[

        "Patient ID",

        "Test Type",

        "Booking Date (YYYY-MM-DD)",

        "Result"

    ]

    entries=[]

    for i,text in enumerate(labels):

        tk.Label(

            win,

            text=text,

            bg="#EAF4FF",

            fg="#0B5394",

            font=("Arial",10,"bold")

        ).grid(row=i,column=0,padx=10,pady=10)

        e=tk.Entry(win,width=28)

        e.grid(row=i,column=1)

        entries.append(e)

    def save():

        patient=hospital.search_patient(int(entries[0].get()))

        if patient is None:

            messagebox.showerror("Error","Patient Not Found")

            return

        vital=VitalSigns(

            patient,

            entries[1].get()

        )

        appointment=vital.book_appointment(entries[2].get())

        result=vital.enter_result(entries[3].get())

        patient.vital_signs=vital

        show(appointment+"\n\n"+result)

        win.destroy()

    tk.Button(

        win,

        text="Save",

        width=18,

        bg="#1976D2",

        fg="white",

        font=("Arial",10,"bold"),

        command=save

    ).grid(row=4,column=0,columnspan=2,pady=20)

# ==========================================================
#                 DISPLAY RECORD
# ==========================================================

def display_record():

    win = tk.Toplevel(root)

    win.title("Display Record")

    win.geometry("320x150")

    win.configure(bg="#EAF4FF")

    tk.Label(

        win,

        text="Patient ID",

        bg="#EAF4FF",

        fg="#0B5394",

        font=("Arial",10,"bold")

    ).pack(pady=10)

    patient_id = tk.Entry(win, width=25)

    patient_id.pack()

    def display():

        try:

            record = hospital.display_record(

                int(patient_id.get())

            )

            show(record)

            win.destroy()

        except:

            messagebox.showerror(

                "Error",

                "Invalid Patient ID"

            )

    tk.Button(

        win,

        text="Display",

        width=15,

        bg="#1976D2",

        fg="white",

        activebackground="#1565C0",

        activeforeground="white",

        font=("Arial",10,"bold"),

        command=display

    ).pack(pady=15)


# ==========================================================
#                     FIRST AID
# ==========================================================

def first_aid():

    win = tk.Toplevel(root)

    win.title("First Aid")

    win.geometry("350x280")

    win.configure(bg="#EAF4FF")

    tk.Label(

        win,

        text="Choose Injury",

        bg="#EAF4FF",

        fg="#0B5394",

        font=("Arial",12,"bold")

    ).pack(pady=10)

    choices = [

        "1 - Cut",

        "2 - Epilepsy",

        "3 - Fracture",

        "4 - CPR",

        "5 - Choking",

        "6 - Burn"

    ]

    choice = tk.StringVar()

    choice.set(choices[0])

    menu = tk.OptionMenu(

        win,

        choice,

        *choices

    )

    menu.pack()

    chemical = tk.BooleanVar()

    tk.Checkbutton(

        win,

        text="Chemical Burn",

        variable=chemical,

        bg="#EAF4FF"

    ).pack(pady=10)

    def display():

        injury = Injury()

        number = int(choice.get()[0])

        text = injury.get_first_aid(

            number,

            chemical.get()

        )

        show(text)

        win.destroy()

    tk.Button(

        win,

        text="Show",

        width=15,

        bg="#1976D2",

        fg="white",

        activebackground="#1565C0",

        activeforeground="white",

        font=("Arial",10,"bold"),

        command=display

    ).pack(pady=10)


# ==========================================================
#                     BUTTONS
# ==========================================================

frame = tk.Frame(

    root,

    bg="#EAF4FF"

)

frame.pack(pady=20)

buttons = [

    ("Add Patient", add_patient_window),

    ("View Patients", view_patients),

    ("Search Patient", search_patient),

    ("Update Patient", update_patient),

    ("Delete Patient", delete_patient),

    ("Diagnosis", add_diagnosis),

    ("Treatment", add_treatment),

    ("Vital Signs", add_vital_signs),

    ("First Aid", first_aid),

    ("Display Record", display_record)

]

row = 0
column = 0

for text, command in buttons:

    button = tk.Button(

        frame,

        text=text,

        width=22,

        height=2,

        bg="#1976D2",

        fg="white",

        activebackground="#1565C0",

        activeforeground="white",

        font=("Arial",10,"bold"),

        command=command

    )

    button.grid(

        row=row,

        column=column,

        padx=12,

        pady=12

    )

    column += 1

    if column == 2:

        column = 0

        row += 1


# ==========================================================
#                     START PROGRAM
# ==========================================================

root.mainloop()