class Injury:

    def __init__(self):

        self.instructions = ""

    # ---------------- First Aid ---------------- #

    def get_first_aid(self, choice, chemical=False):

        if choice == 1:

            self.instructions = (
                "CUT\n\n"
                "1- Press firmly on the wound with a clean cloth.\n"
                "2- Wash the wound with clean water.\n"
                "3- Apply antiseptic.\n"
                "4- Cover with a sterile bandage."
            )

        elif choice == 2:

            self.instructions = (
                "EPILEPSY\n\n"
                "1- Lay the patient on one side.\n"
                "2- Protect the head.\n"
                "3- Do NOT put anything inside the mouth."
            )

        elif choice == 3:

            self.instructions = (
                "FRACTURE\n\n"
                "1- Do not move the injured limb.\n"
                "2- Immobilize the fracture.\n"
                "3- Go to the nearest hospital."
            )

        elif choice == 4:

            self.instructions = (
                "CPR\n\n"
                "1- Push hard and fast in the center of the chest.\n"
                "2- Rate: 100-120 compressions per minute.\n"
                "3- Continue until medical help arrives."
            )

        elif choice == 5:

            self.instructions = (
                "CHOKING\n\n"
                "1- Give 5 back blows.\n"
                "2- Give 5 abdominal thrusts.\n"
                "3- Repeat until the object comes out."
            )

        elif choice == 6:

            if chemical:

                self.instructions = (
                    "CHEMICAL BURN\n\n"
                    "1- Wash with running water for at least 20 minutes.\n"
                    "2- Remove contaminated clothes.\n"
                    "3- Call emergency services."
                )

            else:

                self.instructions = (
                    "THERMAL BURN\n\n"
                    "1- Cool the burn under running water.\n"
                    "2- Do NOT use ice or toothpaste.\n"
                    "3- Cover with sterile gauze."
                )

        else:

            self.instructions = "Invalid Choice."

        return self.instructions

    # ---------------- Display ---------------- #

    def display_instruction(self):

        return self.instructions