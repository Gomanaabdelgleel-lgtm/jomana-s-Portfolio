class Treatment:

    def __init__(self):

        self.medicine_name = ""
        self.dosage = ""
        self.duration = ""
        self.instructions = ""

    # ---------------- Add Treatment ---------------- #

    def add_treatment(
        self,
        medicine_name,
        dosage,
        duration,
        instructions
    ):

        self.medicine_name = medicine_name
        self.dosage = dosage
        self.duration = duration
        self.instructions = instructions

    # ---------------- Display Treatment ---------------- #

    def display_treatment(self):

        return (
            f"\n========== Treatment ==========\n"
            f"Medicine Name : {self.medicine_name}\n"
            f"Dosage : {self.dosage}\n"
            f"Duration : {self.duration}\n"
            f"Instructions : {self.instructions}\n"
        )

    # ---------------- Update Treatment ---------------- #

    def update_treatment(
        self,
        medicine_name,
        dosage,
        duration,
        instructions
    ):

        self.medicine_name = medicine_name
        self.dosage = dosage
        self.duration = duration
        self.instructions = instructions

    # ---------------- Delete Treatment ---------------- #

    def delete_treatment(self):

        self.medicine_name = ""
        self.dosage = ""
        self.duration = ""
        self.instructions = ""

    # ---------------- String ---------------- #

    def __str__(self):

        return (
            f"{self.medicine_name} | "
            f"{self.dosage} | "
            f"{self.duration}"
        )