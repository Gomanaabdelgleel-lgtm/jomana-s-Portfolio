class HospitalSystem:

    def __init__(self):

        self.__patients = []

    # ---------------- Add Patient ---------------- #

    def add_patient(self, patient):

        if self.search_patient(patient.patient_id):

            print("Patient ID already exists.")
            return False

        self.__patients.append(patient)

        print("Patient added successfully.")

        return True

    # ---------------- Search Patient ---------------- #

    def search_patient(self, patient_id):

        for patient in self.__patients:

            if patient.patient_id == patient_id:

                return patient

        return None

    # ---------------- View Patients ---------------- #

    def view_patients(self):

        if not self.__patients:

            return "No patients found."

        text = "\n========== Patients ==========\n\n"

        for patient in self.__patients:

            text += str(patient)
            text += "\n-----------------------------\n"

        return text

    # ---------------- Update Patient ---------------- #

    def update_patient(
        self,
        patient_id,
        medical_record_number,
        patient_name,
        patient_age,
        patient_gender,
        patient_phone_number,
        patient_blood_type,
        patient_address
    ):

        patient = self.search_patient(patient_id)

        if patient:

            patient.update_patient(
                medical_record_number,
                patient_name,
                patient_age,
                patient_gender,
                patient_phone_number,
                patient_blood_type,
                patient_address
            )

            print("Patient updated successfully.")
            return True

        print("Patient not found.")
        return False

    # ---------------- Delete Patient ---------------- #

    def remove_patient(self, patient_id):

        patient = self.search_patient(patient_id)

        if patient:

            self.__patients.remove(patient)

            print("Patient removed successfully.")

            return True

        print("Patient not found.")

        return False

    # ---------------- Display Full Record ---------------- #

    def display_record(self, patient_id):

        patient = self.search_patient(patient_id)

        if patient is None:

            return "Patient not found."

        record = patient.display_patient()

        # Diagnosis

        if patient.diagnosis:

            record += "\n========== Diagnosis ==========\n"

            for item in patient.diagnosis.diagnosisname:

                record += f"- {item}\n"

            record += f"\nDoctor : {patient.diagnosis.doctorname}"
            record += f"\nDate : {patient.diagnosis.date}"
            record += f"\nNotes : {patient.diagnosis.notes}\n"

        # Treatment

        if patient.treatment:

            record += "\n========== Treatment ==========\n"

            record += (
                f"Medicine : {patient.treatment.medicine_name}\n"
                f"Dosage : {patient.treatment.dosage}\n"
                f"Duration : {patient.treatment.duration}\n"
                f"Instructions : {patient.treatment.instructions}\n"
            )

        # Vital Signs

        if patient.vital_signs:

            record += "\n========== Vital Signs ==========\n"

            record += (
                f"Test : {patient.vital_signs.test_type}\n"
                f"Result : {patient.vital_signs.test_result}\n"
            )

        return record

    # ---------------- Count Patients ---------------- #

    def total_patients(self):

        return len(self.__patients)