from datetime import datetime, timedelta


class VitalSigns:

    def __init__(self, patient, test_type):

        self.patient = patient
        self.test_type = test_type.lower()

        self.booking_date = None
        self.result_date = None
        self.test_result = None

    # ---------------- Book Appointment ---------------- #

    def book_appointment(self, date_str):

        self.booking_date = datetime.strptime(date_str, "%Y-%m-%d")

        self.result_date = self.booking_date + timedelta(days=3)

        fasting_tests = [
            "sugar",
            "fasting blood sugar",
            "cholesterol",
            "lipid profile",
            "كبد",
            "وظائف كبد",
            "سكر"
        ]

        requires_fasting = any(
            test in self.test_type
            for test in fasting_tests
        )

        sms = (
            f"\n[SMS Sent to {self.patient.patient_phone_number}]\n"
            f"Hello {self.patient.patient_name}\n"
            f"Your appointment for '{self.test_type}' "
            f"is confirmed on {date_str}.\n"
        )

        if requires_fasting:

            sms += (
                "IMPORTANT: "
                "This test requires 8-12 hours of fasting.\n"
            )

        else:

            sms += "No fasting is required.\n"

        sms += (
            f"Result Date : "
            f"{self.result_date.strftime('%Y-%m-%d')}"
        )

        return sms

    # ---------------- Enter Result ---------------- #

    def enter_result(self, result):

        self.test_result = float(result)

        return self.analyze_result()

    # ---------------- Analyze Result ---------------- #

    def analyze_result(self):

        if self.test_result is None:

            return "No Result Entered."

        val = self.test_result

        age = self.patient.patient_age

        gender = self.patient.patient_gender.lower()

        # ---------------- Sugar ---------------- #

        if "sugar" in self.test_type or "سكر" in self.test_type:

            if age > 65:

                if val > 220:
                    return "CRITICAL : High Blood Sugar."

                elif val > 140:
                    return "WARNING : Elevated Blood Sugar."

                elif val < 80:
                    return "CRITICAL : Low Blood Sugar."

                else:
                    return "NORMAL"

            else:

                if val > 200:
                    return "CRITICAL : High Blood Sugar."

                elif val > 100:
                    return "WARNING : Prediabetes."

                elif val < 70:
                    return "CRITICAL : Low Blood Sugar."

                else:
                    return "NORMAL"

        # ---------------- Pressure ---------------- #

        elif "pressure" in self.test_type or "ضغط" in self.test_type:

            normal = 135 if age >= 60 else 120

            critical = 170 if age >= 60 else 160

            if val > critical:

                return "CRITICAL : High Blood Pressure."

            elif val > normal:

                return "WARNING : High Blood Pressure."

            elif val < 90:

                return "WARNING : Low Blood Pressure."

            else:

                return "NORMAL"

        # ---------------- Hemoglobin ---------------- #

        elif (
            "hemoglobin" in self.test_type
            or "hb" in self.test_type
            or "أنيميا" in self.test_type
        ):

            if gender == "male":

                low = 13.8
                high = 17.2
                severe = 9

            else:

                low = 12.1
                high = 15.1
                severe = 8

            if val < severe:

                return "CRITICAL : Severe Anemia."

            elif val < low:

                return "WARNING : Mild Anemia."

            elif val > high:

                return "WARNING : High Hemoglobin."

            else:

                return "NORMAL"

        # ---------------- Kidney ---------------- #

        elif (
            "kidney" in self.test_type
            or "creatinine" in self.test_type
            or "كلى" in self.test_type
        ):

            upper = 1.3 if gender == "male" else 1.1

            if val > 3:

                return "CRITICAL : Kidney Failure."

            elif val > upper:

                return "WARNING : High Creatinine."

            elif val < 0.5:

                return "WARNING : Low Creatinine."

            else:

                return "NORMAL"

        # ---------------- Liver ---------------- #

        elif (
            "liver" in self.test_type
            or "alt" in self.test_type
            or "كبد" in self.test_type
        ):

            upper = 50 if gender == "male" else 35

            if val > 150:

                return "CRITICAL : Liver Damage."

            elif val > upper:

                return "WARNING : High Liver Enzymes."

            else:

                return "NORMAL"

        # ---------------- Cholesterol ---------------- #

        elif (
            "cholesterol" in self.test_type
            or "ldl" in self.test_type
            or "كوليسترول" in self.test_type
        ):

            if val > 190:

                return "CRITICAL : High Cholesterol."

            elif val > 100:

                return "WARNING : Borderline High Cholesterol."

            else:

                return "NORMAL"

        return "Unknown Test Type."