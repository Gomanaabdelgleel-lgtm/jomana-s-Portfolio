class Diagnosis:

    def __init__(self, diagnosis_id, doctor_name, date):

        self.diagnosisID = diagnosis_id
        self.doctorname = doctor_name
        self.date = date

        self.diagnosisname = []
        self.notes = ""

    def add_diagnosis(
        self,
        temperature,
        headache,
        headache_degree,
        stomach_pain,
        stomach_degree,
        cough,
        throat_pain,
        burn,
        burn_degree
    ):

        self.diagnosisname.clear()

        # Fever & Respiratory

        if cough:

            if 38 <= temperature < 39:
                self.diagnosisname.append("Common Cold")

            elif temperature >= 39:
                self.diagnosisname.append("Flu")

        elif throat_pain:

            self.diagnosisname.append("Tonsillitis")

        else:

            if 37 <= temperature < 38:
                self.diagnosisname.append("Mild Fever")

            elif 38 <= temperature < 39:
                self.diagnosisname.append("Viral Fever")

            elif temperature >= 39:
                self.diagnosisname.append("High Fever")

            else:
                self.diagnosisname.append("Normal Temperature")

        # Headache

        if headache:

            if headache_degree <= 5:
                self.diagnosisname.append("Mild Headache")

            else:
                self.diagnosisname.append("Severe Headache")

        # Stomach

        if stomach_pain:

            if stomach_degree <= 5:
                self.diagnosisname.append("Mild Stomach Ache")

            else:
                self.diagnosisname.append("Gastroenteritis")

        # Throat

        if throat_pain:
            self.diagnosisname.append("Sore Throat")

        # Burn

        if burn:

            if burn_degree <= 3:
                self.diagnosisname.append("First Degree Burn")

            elif burn_degree <= 7:
                self.diagnosisname.append("Second Degree Burn")

            else:
                self.diagnosisname.append("Third Degree Burn")

    def update_diagnosis(self, diagnosis, notes):

        self.diagnosisname.append(diagnosis)
        self.notes = notes

    def delete_diagnosis(self):

        self.diagnosisname.clear()
        self.notes = ""

    def display_diagnosis(self):

        text = (
            "\n========== Diagnosis ==========\n"
            f"Diagnosis ID : {self.diagnosisID}\n"
            f"Doctor : {self.doctorname}\n"
            f"Date : {self.date}\n\n"
            "Diagnosis:\n"
        )

        for item in self.diagnosisname:
            text += f"- {item}\n"

        text += f"\nNotes : {self.notes}"

        return text