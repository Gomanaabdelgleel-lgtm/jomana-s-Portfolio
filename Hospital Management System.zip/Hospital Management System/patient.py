class Patient:

    def __init__(
        self,
        patient_id,
        medical_record_number,
        patient_name,
        patient_age,
        patient_gender,
        patient_phone_number,
        patient_blood_type,
        patient_address
    ):

        self.patient_id = patient_id
        self.medical_record_number = medical_record_number
        self.patient_name = patient_name
        self.patient_age = patient_age
        self.patient_gender = patient_gender
        self.patient_phone_number = patient_phone_number
        self.patient_blood_type = patient_blood_type
        self.patient_address = patient_address

        # Related Objects
        self.diagnosis = None
        self.treatment = None
        self.vital_signs = None

    def display_patient(self):

        return (
            f"\n========== Patient Information ==========\n"
            f"Patient ID : {self.patient_id}\n"
            f"Medical Record : {self.medical_record_number}\n"
            f"Name : {self.patient_name}\n"
            f"Age : {self.patient_age}\n"
            f"Gender : {self.patient_gender}\n"
            f"Phone : {self.patient_phone_number}\n"
            f"Blood Type : {self.patient_blood_type}\n"
            f"Address : {self.patient_address}\n"
        )

    def update_patient(
        self,
        medical_record_number,
        patient_name,
        patient_age,
        patient_gender,
        patient_phone_number,
        patient_blood_type,
        patient_address
    ):

        self.medical_record_number = medical_record_number
        self.patient_name = patient_name
        self.patient_age = patient_age
        self.patient_gender = patient_gender
        self.patient_phone_number = patient_phone_number
        self.patient_blood_type = patient_blood_type
        self.patient_address = patient_address

    def __str__(self):

        return (
            f"ID : {self.patient_id} | "
            f"Name : {self.patient_name} | "
            f"Age : {self.patient_age}"
        )
